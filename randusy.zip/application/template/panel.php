 <div>
 	<div class="hide" id="navigation">
 		<div>
 		<ul class="floatLeft">
 			<li><button id="home">Home</button></li>
 			<li><button id="cv">My CV</button></li>
 			<li><button id="blog">Blog</button></li>
 			<li><button id="gallery">My Gallery</button></li>
 			<li><button id="contact">My Contact</button></li>
 			<li><button id="aboutme">About Me</button></li> 
 		</ul>
 		
 		<button id="closeButton" class="floatRight">Close</button> 
 		<h3 class="whiteText"><?php echo Day::daysDate()  ?></h3>
 		</div>
 		
 		<div class="white hide backShadowRounded" id="links">
 			
 		</div>
 	</div>
 </div>