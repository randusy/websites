 
<div id="footer" class="backgroundGradient">
	<h3>Email: <a href="mailto:info@randusy.com">info@randusy.com</a></h3>
	<h3>Karisa Katana Randu &copy;<?php echo Day::daysYear() ?> All Rights Reserved</h3>
</div>
</div>
</body>
</html>