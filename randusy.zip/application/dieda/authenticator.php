<?php 
	class Authenticator
	{
		 
				
		public static function authenticate($word,$hash)
		{ 
		  if(crypt($word,$hash) === $hash)
		  { 
			  return true;
		  }else{
		  	return false;
		  }
		} 		 		 
	}
?>
