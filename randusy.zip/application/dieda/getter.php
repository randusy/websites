<?php 
class Getter extends User
{
	private static $loginErrorTitleMsg = "Login Error Message";
	private static $signUpErrorTitleMsg = "Registration Error Message";
	private static $signUpSuccessTitleMsg = "Registration Massage";
	
	public static function getSignUpSuccessTitleMsg()
	{
		return self::$signUpSuccessTitleMsg;
	}
	public static function getSignUpErrorTitleMsg()
	{
		return self::$signUpErrorTitleMsg;
	}
	public static function getLoginErrorTitleMsg()
	{
		return self::$loginErrorTitleMsg;
	}
	public function getUserName()
		{		  
			try
			{
				$mail = $this->email;
				$retreaved = new Retreaver("LIMIT 1","users","email",$mail);
				return $retreaved->rows['firstname'];				  
			}catch(Exception $e)
			{
				throw new Exception("User Not Available");
			}			  
		} 
		public function getMail()
		{
			$user = new User();
			return $user->isUserMailSet();
		}  
		public static function getHash($word)
		{
			$cost = 10;
			$salt = strtr(base64_encode(mcrypt_create_iv(16, MCRYPT_DEV_URANDOM)), '+', '.');
			$salt = sprintf('$2a$%02d$', $cost) . $salt;
			$hash = crypt($word, $salt);
			return $hash;
		}
		public static function getUserFullName()
		{
			
		}
		public static function getUserStatus()
		{
			return "root";
		} 

}
?>
