<?php
 require_once '../application/initialise.php';
    new Template();
?>
