<div class="center dominantColor" id="ajaxHolder">
	<div id="notification"></div>
	<div class="floatLeft border noMargAndPad" id="containerRight"> 
		<img class="fitWidhtHeight" src="<?php echo UPL ?>profile/daga.jpeg" />
	</div>
	<div class="floatRight border white" id="containerLeft">
		 
		<h3>Welcome to <?php echo SN?>'s Website </h3> 
		<p>Hi Out There...!</p> 
		<p>I'm So Exited That You Have Visited My Website, Please Take Your Time And Tour The Site To
			Find The Information That You Need About Me. Enjoy...!</p> 
		<p>Actually, It Realy Feels Beautiful To Me That You Are Here, Let Me Take The Pleasure To Narate To You Breifly
			Who I'm</p>
		<p>Well, I Was Born In Kaloleni-Giriama In <a target="_blank" href="http://www.kilifi.go.ke">Kilifi County-Kenya</a>, I Grew Up In Vishakani Sub-Location In A Village Called Kityege
			Where My Home Is Currently. I Went To <a target="_blank" href="https://www.facebook.com/pages/St-Michael-Full-Primary-School-Kaloleni-Giryama/378566995559380">ST. Michaels Primary School</a>, Then Later Joined <a target="_blank" href="https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CB4QFjAA&url=https%3A%2F%2Fwww.facebook.com%2Fpages%2Fmariakani-secondary-school%2F115950438415202&ei=k-NIVfmmMYvaao3hgaAI&usg=AFQjCNEsQs1UMvZyIy96DRUTpFfrNHDItw&sig2=AXM2z9X-fAwsvxRAXzhLKA">Mariakani Secondary School</a>
			Which Is Still In Kilifi County. Thereafter I Joined <a target="_blank" href="http://www.busogauniversity.ac.ug">Busoga University</a> In Iganga-Uganda For My 
			Bachelor's Degree, Later I Joined <a target="_blank" href="http://www.kibabiiuniversity.ac.ke">Kibabii University College</a> For My Masters Degree</p>
		<p>Now that You Briefly Know Something About Me, Thats Great But If You Would Like To Know Much ABout Me 
			Please Click On The Main Menu Button And Choose The About Me Button On The Panel</p>
		<p>If You Happen To Know Me And You Have Been My Friend Please Feel Free And Sign Up For An Account With My
			Site And Then We Can Communicate</p>
		<p class="centerText">Else Hit On The Main Menu And Browse The Site <br>
		 Enjoy...! Enjoy...! Enjoy...!<br />
		 Randusy</p> 
	</div>
</div>