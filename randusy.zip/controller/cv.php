<?php
require_once '../application/dieda/day.php';
echo '  
	<div class="border center white"><h1>Karisa Katana Randu Curriculum Vitae '.Day::daysYear().'</h1> <hr>
	 <table class="cvTable" border=0 >
		 <caption><h3>Personal Information </h3> </caption>
		 <ul>
		 <tr><td ><li>Date of Birth	</li></td><td>: 23-11-1989 </td></tr>
		 <tr><td><li>Place of Birth</li></td><td>: Kilifi-Kenya</td></tr>
		 <tr><td><li>Citizenship</li></td><td>: Kenyan</td></tr>
		 <tr><td><li>Visa Status</li></td><td>: N/A</td></tr>
		 <tr><td><li>Gender</li></td><td>: Male</td></tr>
		 <tr><td><li>Marital Status</li></td><td >: Single</td></tr>
		 <tr><td><li>Children</li></td><td >: N/A</td></tr>
		 </ul>
	 </table><hr>
	 <table class="cvTable" border=0 >
		 <caption><h3>Objectives</h3> </caption>
		<ul><tr><td><li>
		 	Seeking a position to utilize my skills and abilities in the Information Technology 
		 	Industry that offers Professional growth while being resourceful, innovative and flexible.
		 </li></td></tr></ul>
	 </table><hr>
	 <table class="cvTable" border=0 >
		 <caption><h3>Experience</h3> </caption>
		<ul>
			<tr><td ><li><i>Work History </i></li></td><td>: Internship experience At Pwani University College ICT</td></tr>
			<tr><td ><li><i>Academic Positions</i></li></td><td>: None </td></tr>
			<tr><td ><li><i>Research and Training </i></li></td><td>: Extensive knowledge of Adobe Dreamweaver CS6 ,Microsoft Office Programs,
				 Adobe Photoshop CS5 and Adobe Flash professional CS5 </td></tr>
		</ul>
	 </table><hr>
	 <table class="cvTable" border=0 >
		 <caption><h3>Education</h3> </caption>
		<ul>
			<tr><td ><li><i>Primary School</i></li></td><td>: St. Michael’s Primary school(1996-2004)</td></tr>
			<tr><td ><li><i>High School</i></li></td><td>: Mariakani Secondary school (2005-2008) </td></tr>
			<tr><td ><li><i>University</i></li></td><td>: Busoga University (2009-2012) </td></tr>
		</ul>
	 </table><hr>
	 <table class="cvTable" border=0 >
		 <caption><h3>Professional Qualifications</h3> </caption>
		<ul><tr><td><li>
		 	Kenya Certificate of Primary Education (KCPE).
		 </li></td></tr>
		 <tr><td><li>
		 	O’ Level Kenya Certificate of Secondary Education (KCSE).
		 </li></td></tr>
		 <tr><td><li>
		 	A’ Level Certificate of Busoga University Uganda,
		 </li></td></tr>
		 <tr><td><li>
		 	Bachelor’s Degree of Computer Science of Busoga University Uganda
		 </li></td></tr>
		 </ul>
	 </table><hr>
	 
	 <table class="cvTable" border=0 >
		 <caption><h3>Awards</h3> </caption>
		<ul><tr><td><li>
		 	Awarded with KCPE certificate in 2004
		 </li></td></tr>
		 <tr><td><li>
		 	Awarded with a certificate of merit with a position Two in the Kilifi 
		 	District Secondary schools Heads Association in an event of hockey Boys 
		 	game during the annual district games on 17th march 2006.
		 </li></td></tr>
		 <tr><td><li>
		 	Awarded a certificate of participation at the coast province mathematics contest 
		 	hosted by Aldina Visram high school on 13th September 2008
		 </li></td></tr>
		 <tr><td><li>
		 	Awarded with an O’ level KCSE certificate with a C plain Mean Grade in March 2009 
		 </li></td></tr>
		 <tr><td><li>
		 	Awarded with an A’ level certificate of Busoga University in October 2009 
		 </li></td></tr>
		 <tr><td><li>
		 	Awarded with a Bachelor of computer Science of Busoga University with honors upper division in August 2012
		 </li></td></tr>
		 </ul>
	 </table><hr>
	 
	  <table class="cvTable" border=0 >
		 <caption><h3>Skills Summary</h3> </caption>
		<ul><tr><td><li>
		 	Microsoft Office, Internet
		 </li></td></tr>
		 <tr><td><li>
		 	Programming ability in PHP,SQL,C# and CSS
		 </li></td></tr>
		 <tr><td><li>
		 	Fluent in Kiswahili and English
		 </li></td></tr>
		 <tr><td><li>
		 	Computer hardware and software troubleshooting, networking computers, servicing computers 
		 </li></td></tr>
		 </ul>
	 </table><hr>
	  
</div>';
?>